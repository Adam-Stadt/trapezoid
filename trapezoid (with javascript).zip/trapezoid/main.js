document.getElementById("calc").addEventListener("click", calculate);

function calculate() {
    // Input
    let sideA = +document.getElementById("inputA").value;
    let sideB = +document.getElementById("inputB").value;
    let height = +document.getElementById("inputH").value;

    // Process
    let output = 0.5 * (sideA +++ sideB) * height;
    
    // this little section removes the 's' at the end of 'units' if the area is equal to 1
    let plural = "s"
    if (output === 1) {
        plural = ""
    }

    // Output 
    document.getElementById("answer").innerHTML = output
    document.getElementById("plural").innerHTML = plural
}